let sentimentChart = null;
let keywordChart = null;

const $ = (id) => document.getElementById(id);

function setText(id, value) {
  $(id).textContent = value;
}

function percentage(value, total) {
  return total ? `${Math.round((value / total) * 100)}%` : "0%";
}

function updateStats(data) {
  setText("totalComments", data.totalComments);
  setText("positive", data.positive);
  setText("negative", data.negative);
  setText("neutral", data.neutral);
  setText("spam", data.spam);

  setText("positivePct", percentage(data.positive, data.totalComments));
  setText("negativePct", percentage(data.negative, data.totalComments));
  setText("neutralPct", percentage(data.neutral, data.totalComments));
  setText("spamPct", percentage(data.spam, data.totalComments));

  setText("donutTotal", data.totalComments);
  setText("legendPositive", data.positive);
  setText("legendNegative", data.negative);
  setText("legendNeutral", data.neutral);
  setText("legendSpam", data.spam);
  setText("commentCount", `${data.totalComments} comments`);
}

function renderSentiment(data) {
  const ctx = $("sentimentChart").getContext("2d");
  if (sentimentChart) sentimentChart.destroy();

  sentimentChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Positive", "Negative", "Neutral", "Spam"],
      datasets: [{
        data: [data.positive, data.negative, data.neutral, data.spam],
        backgroundColor: ["#20a56b", "#e05b68", "#9a99a2", "#d69a20"],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "72%",
      plugins: { legend: { display: false } }
    }
  });
}

function renderKeywords(data) {
  const empty = $("keywordEmpty");
  if (!data.keywords || !data.keywords.length) {
    empty.style.display = "block";
    if (keywordChart) keywordChart.destroy();
    return;
  }
  empty.style.display = "none";

  const ctx = $("keywordChart").getContext("2d");
  if (keywordChart) keywordChart.destroy();

  keywordChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: data.keywords.map(x => x.word),
      datasets: [{
        label: "Mentions",
        data: data.keywords.map(x => x.count),
        backgroundColor: "#7657e8",
        borderRadius: 6,
        barThickness: 18
      }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: "#eeeef3" } },
        y: { grid: { display: false } }
      },
      plugins: { legend: { display: false } }
    }
  });
}

function badgeClass(sentiment) {
  return {
    Positive: "badge-positive",
    Negative: "badge-negative",
    Neutral: "badge-neutral",
    Spam: "badge-spam"
  }[sentiment] || "badge-neutral";
}

function renderComments(comments) {
  const body = $("commentsBody");
  body.innerHTML = "";

  if (!comments.length) {
    body.innerHTML = '<tr><td colspan="4" class="empty-cell">No comments were returned for this video.</td></tr>';
    return;
  }

  comments.forEach((item, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${index + 1}</td>
      <td class="user">${escapeHtml(item.user)}</td>
      <td class="comment">${escapeHtml(item.comment)}</td>
      <td><span class="badge ${badgeClass(item.sentiment)}">${item.sentiment}</span></td>
    `;
    body.appendChild(row);
  });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function analyze() {
  const url = $("youtubeUrl").value.trim();
  const button = $("analyzeBtn");
  const message = $("message");

  if (!url) {
    message.textContent = "Please paste a YouTube video URL.";
    message.className = "message error";
    return;
  }

  button.disabled = true;
  button.innerHTML = "ANALYZING... <span>↻</span>";
  message.textContent = "Fetching comments and analyzing sentiment...";
  message.className = "message";

  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });

    const data = await response.json();

    if (!response.ok) throw new Error(data.error || "Analysis failed.");

    updateStats(data);
    renderSentiment(data);
    renderKeywords(data);
    renderComments(data.comments);

    message.textContent = `Analysis complete — ${data.totalComments} comments processed.`;
    message.className = "message";
  } catch (error) {
    message.textContent = error.message || "Error connecting to backend.";
    message.className = "message error";
  } finally {
    button.disabled = false;
    button.innerHTML = 'RUN ANALYSIS <span>→</span>';
  }
}

$("analyzeBtn").addEventListener("click", analyze);
$("youtubeUrl").addEventListener("keydown", (event) => {
  if (event.key === "Enter") analyze();
});
