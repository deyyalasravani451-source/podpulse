import os
import re
from collections import Counter
from urllib.parse import urlparse, parse_qs

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

load_dotenv()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
API_KEY = os.getenv("YOUTUBE_API_KEY")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)

analyzer = SentimentIntensityAnalyzer()

STOPWORDS = {
    "the","and","for","that","this","with","you","your","was","are","have","from",
    "but","not","they","what","about","very","just","like","been","will","would",
    "there","their","here","episode","video","podcast","youtube","really","more",
    "can","all","our","its","it's","this","these","those","into","than","then",
    "who","how","why","when","where","which","while","also","too","had","has",
    "his","her","him","she","he","them","out","get","got","did","does","don"
}

SPAM_TERMS = [
    "subscribe to my channel",
    "check my channel",
    "visit my channel",
    "free subscribers",
    "make money fast",
    "click here",
    "promo code",
    "follow me",
    "whatsapp me",
]

def extract_video_id(url):
    try:
        parsed = urlparse(url.strip())
        host = parsed.netloc.lower()

        if "youtu.be" in host:
            return parsed.path.strip("/").split("/")[0]

        if "youtube.com" in host:
            if parsed.path == "/watch":
                return parse_qs(parsed.query).get("v", [None])[0]
            if parsed.path.startswith("/shorts/"):
                return parsed.path.split("/")[2]
            if parsed.path.startswith("/embed/"):
                return parsed.path.split("/")[2]
    except Exception:
        pass
    return None

def is_spam(text):
    t = text.lower()
    if any(term in t for term in SPAM_TERMS):
        return True
    if re.search(r"https?://\S+|www\.\S+", t):
        return True
    if len(re.findall(r"[!$]{2,}", t)) > 0:
        return True
    return False

def sentiment_label(text):
    score = analyzer.polarity_scores(text)["compound"]
    if score >= 0.05:
        return "Positive"
    if score <= -0.05:
        return "Negative"
    return "Neutral"

def fetch_comments(video_id, max_comments=100):
    comments = []
    url = "https://www.googleapis.com/youtube/v3/commentThreads"
    params = {
        "part": "snippet",
        "videoId": video_id,
        "maxResults": 100,
        "textFormat": "plainText",
        "key": API_KEY,
    }

    while len(comments) < max_comments:
        response = requests.get(url, params=params, timeout=20)
        data = response.json()

        if response.status_code != 200:
            message = data.get("error", {}).get("message", "YouTube API request failed")
            reason = data.get("error", {}).get("errors", [{}])[0].get("reason", "")
            raise RuntimeError(f"{message} ({reason})" if reason else message)

        for item in data.get("items", []):
            snippet = item["snippet"]["topLevelComment"]["snippet"]
            comments.append({
                "user": snippet.get("authorDisplayName", "Unknown"),
                "comment": snippet.get("textDisplay", ""),
                "publishedAt": snippet.get("publishedAt", ""),
                "likeCount": snippet.get("likeCount", 0),
            })
            if len(comments) >= max_comments:
                break

        token = data.get("nextPageToken")
        if not token:
            break
        params["pageToken"] = token

    return comments

@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.post("/api/analyze")
def analyze():
    if not API_KEY:
        return jsonify({
            "error": "YOUTUBE_API_KEY is missing. Create backend/.env and add your YouTube Data API v3 key."
        }), 500

    body = request.get_json(silent=True) or {}
    youtube_url = body.get("url", "")
    video_id = extract_video_id(youtube_url)

    if not video_id:
        return jsonify({"error": "Invalid YouTube URL. Please paste a normal YouTube video URL."}), 400

    try:
        raw_comments = fetch_comments(video_id)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 502

    processed = []
    counts = Counter()
    words = Counter()

    for item in raw_comments:
        text = item["comment"]
        spam = is_spam(text)
        label = "Spam" if spam else sentiment_label(text)

        counts[label] += 1

        for word in re.findall(r"[A-Za-z][A-Za-z'-]{2,}", text.lower()):
            if word not in STOPWORDS:
                words[word] += 1

        processed.append({
            **item,
            "sentiment": label,
            "spam": spam,
        })

    total = len(processed)
    keywords = [{"word": w, "count": c} for w, c in words.most_common(10)]

    return jsonify({
        "videoId": video_id,
        "totalComments": total,
        "positive": counts["Positive"],
        "negative": counts["Negative"],
        "neutral": counts["Neutral"],
        "spam": counts["Spam"],
        "keywords": keywords,
        "comments": processed,
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
