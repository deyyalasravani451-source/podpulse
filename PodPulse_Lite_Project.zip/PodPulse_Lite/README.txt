PODPULSE LITE - COMPLETE SETUP GUIDE
=====================================

1. REQUIREMENTS
---------------
Install:
- Python 3.10 or newer
- VS Code (recommended)
- A Google account for YouTube Data API v3

2. PROJECT STRUCTURE
--------------------
PodPulse_Lite/
  backend/
    app.py
    requirements.txt
    .env.example
  frontend/
    index.html
    style.css
    app.js
  README.txt

3. INSTALL BACKEND
------------------
Open VS Code terminal:

cd backend

Create virtual environment:
python -m venv venv

Windows activation:
venv\Scripts\activate

Install packages:
pip install -r requirements.txt

4. CREATE YOUTUBE API KEY
-------------------------
In Google Cloud Console:
- Create/select a project.
- Enable "YouTube Data API v3".
- Create an API key.

Keep the key private.

5. CREATE .env
--------------
Inside backend, make a file named:

.env

Copy the following into it:

YOUTUBE_API_KEY=YOUR_REAL_API_KEY

6. START THE SERVER
-------------------
From the backend folder:

python app.py

You should see:

Running on http://127.0.0.1:5000

7. OPEN THE APP
---------------
Open this in Chrome:

http://127.0.0.1:5000

Do NOT double-click frontend/index.html.

8. TEST
-------
Paste a YouTube video URL and click RUN ANALYSIS.

Example formats:
https://www.youtube.com/watch?v=VIDEO_ID
https://youtu.be/VIDEO_ID

9. FEATURES
-----------
- YouTube comment collection
- Positive / Negative / Neutral sentiment
- Rule-based spam detection
- Top keyword extraction
- Sentiment doughnut chart
- Keyword bar chart
- Comments table with usernames

10. COMMON ERRORS
-----------------
"YOUTUBE_API_KEY is missing":
  Check backend/.env.

"Invalid YouTube URL":
  Use a valid YouTube video URL.

"commentsDisabled":
  Try another video.

"quotaExceeded":
  The Google API quota for the project has been exceeded.

"Error connecting to backend":
  Make sure python app.py is still running and open:
  http://127.0.0.1:5000

11. PROJECT EXPLANATION
-----------------------
Frontend:
HTML + CSS + JavaScript + Chart.js

Backend:
Python + Flask

External API:
YouTube Data API v3

Sentiment:
VADER Sentiment

Communication:
The browser sends POST /api/analyze with the YouTube URL.
Flask fetches comments, analyzes them, and returns JSON.
JavaScript updates the dashboard.

IMPORTANT:
Do not upload or publish your .env file or share your API key.
